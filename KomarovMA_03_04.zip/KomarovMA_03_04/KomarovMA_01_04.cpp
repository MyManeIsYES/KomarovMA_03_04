﻿// KomarovMA_01_04.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

//Класс автомибиль
class Car
{
public:
    string marka;
    string nomernoi_znak;
    string data_vipyska;
    int price;

    Car(string marka, string nomernoi_znak, string data_vipyska, int price)
    {
        marka = marka;
        nomernoi_znak = nomernoi_znak;
        data_vipyska = data_vipyska;
        price = price;
    }
    ~Car(){}
};

int main()
{
    setlocale(LC_ALL, "");
    int status = 0;
    
    ofstream out("text.txt");

   

    if(out.is_open())
    {
        do
        {
            cout << "1 - Ввести новую машину\n2 - Отсортировать\n3 - конец программы\n";
            cout << "Введите режим: ";
            string str;
            cin >> str;
            try 
            {
                status = stoi(str);
            }
            catch(exception e)
            {
                cout << "Error: не верно веденый режим режим\n";
            }
            
            if (status == 1)
            {
                Car car();
                cout << "Введите марку: ";
                cin >> car.marka;
                cout << "Введите номерной знак: ";
                cin >> car.marka;
                cout << "Введите год выпуска: ";
                cin >> car.marka;
                cout << "Введите стоимость: ";
                cin >> car.marka;
            }
            else if (status == 2)
            {

            }
            else if (status == 3) 
            {

            }
            else
            {
                cout << "Error: не выбран режим\n";
            }
        } while (status != 3);
    }
    else 
    {
        cout << "Error: not found file";
    }
    out.close();
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
